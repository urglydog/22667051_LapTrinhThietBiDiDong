import React, { useState } from "react";
import Tiki from './components/tiki'
import PWD from './components/pass'
import LoginScreen from './components/login'
import ReviewScreen from './components/sell_usb'
export default function App() {


  return (
    <ReviewScreen/>
  );
}
