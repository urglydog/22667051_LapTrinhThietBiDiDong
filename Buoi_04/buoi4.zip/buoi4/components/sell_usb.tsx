import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  TextInput,
} from "react-native";

import usb from '../assets/usb.PNG'
import camera from '../assets/camera.PNG'
export default function ReviewScreen() {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");

  return (
    <View style={styles.container}>
      {/* Product Info */}
      <View style={styles.productRow}>
        <Image
          source={usb}
          style={styles.productImage}
        />
        <Text style={styles.productText}>
          USB Bluetooth Music Receiver {"\n"}
          HJX-001 - Biến loa thường thành loa bluetooth
        </Text>
      </View>

      {/* Rating title */}
      <Text style={styles.title}>Cực kỳ hài lòng</Text>

      {/* Stars */}
      <View style={styles.starRow}>
        {[1, 2, 3, 4, 5].map((i) => (
          <TouchableOpacity key={i} onPress={() => setRating(i)}>
            <Text style={[styles.star, i <= rating && styles.starActive]}>★</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Upload image */}
      <TouchableOpacity style={styles.uploadBox}>
        <Image source={camera} style={styles.cameraIcon} />
        <Text style={styles.uploadText}>Thêm hình ảnh</Text>
      </TouchableOpacity>

      {/* Comment */}
      <TextInput
        style={styles.textArea}
        placeholder="Hãy chia sẻ những điều mà bạn thích về sản phẩm"
        placeholderTextColor="#999"
        multiline
        numberOfLines={4}
        value={comment}
        onChangeText={setComment}
      />

      {/* Link */}
      <Text style={styles.link}>https://meet.google.com/nsj-ojwi-xpp</Text>

      {/* Submit button */}
      <TouchableOpacity style={styles.submitButton}>
        <Text style={styles.submitText}>Gửi</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 16,
  },
  productRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  productImage: {
    width: 60,
    height: 60,
    resizeMode: "contain",
    marginRight: 12,
  },
  productText: {
    flex: 1,
    fontSize: 14,
    fontWeight: "500",
  },
  title: {
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    marginVertical: 12,
  },
  starRow: {
    flexDirection: "row",
    justifyContent: "center",
    marginBottom: 20,
  },
  star: {
    fontSize: 32,
    color: "#ccc",
    marginHorizontal: 4,
  },
  starActive: {
    color: "gold",
  },
  uploadBox: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "blue",
    padding: 12,
    marginBottom: 16,
  },
  cameraIcon: {
    width: 24,
    height: 24,
    marginRight: 8,
    // tintColor: "#000",
  },
  uploadText: {
    fontSize: 14,
    fontWeight: "500",
  },
  textArea: {
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 10,
    textAlignVertical: "top",
    minHeight: 100,
    fontSize: 14,
    marginBottom: 8,
  },
  link: {
    fontSize: 12,
    color: "#000",
    marginBottom: 20,
  },
  submitButton: {
    backgroundColor: "#0066FF",
    padding: 14,
    alignItems: "center",
    borderRadius: 4,
  },
  submitText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
});
