import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
} from "react-native";
import user from '../assets/user.PNG'
import lock from '../assets/lock.PNG'
import eye from '../assets/eye.PNG'
export default function LoginScreen() {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <View style={styles.container}>
      {/* Title */}
      <Text style={styles.title}>LOGIN</Text>

      {/* Username input */}
      <View style={styles.inputRow}>
        <Image source={user} style={styles.icon} />
        <TextInput
          placeholder="Name"
          placeholderTextColor="#000"
          style={styles.input}
        />
      </View>

      {/* Password input */}
      <View style={styles.inputRow}>
        <Image source={lock} style={styles.icon} />
        <TextInput
          placeholder="Password"
          placeholderTextColor="#000"
          secureTextEntry={!showPassword}
          style={styles.input}
        />
        <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
          <Image source={eye} style={styles.icon} />
        </TouchableOpacity>
      </View>

      {/* Login button */}
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>LOGIN</Text>
      </TouchableOpacity>

      {/* Forgot password */}
      <TouchableOpacity>
        <Text style={styles.forgotText}>Forgot your password?</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "linear-gradient(to bottom, #FBCB00, #BF9A00)", // iOS/Android không hỗ trợ trực tiếp
    backgroundColor: "#FFD700", // fallback
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#000",
    alignSelf: "flex-start",
    marginBottom: 30,
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#fff",
    backgroundColor: "#C4C4C44D",
    width: "100%",
    marginBottom: 20,
    paddingHorizontal: 10,
    height: 50,
  },
  icon: {
    width: 24,
    height: 24,
    marginRight: 8,
    // tintColor: "#000",
  },
  input: {
    flex: 1,
    color: "#000",
  },
  button: {
    backgroundColor: "#000",
    width: "100%",
    padding: 14,
    alignItems: "center",
    marginTop: 10,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  forgotText: {
    marginTop: 20,
    color: "#000",
    fontWeight: "bold",
  },
});
