import React from 'react';
import {
  View,
  TouchableOpacity,
  StyleSheet,
  Text,
  TextInput,
  CheckBox,
} from 'react-native';
export default function Pwd() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.header_text}>PASSWORD GENERATOR</Text>
      </View>
      <View style={styles.input}>
        <TextInput style={styles.input_result} editable={false}></TextInput>
      </View>
      <View style={styles.row}>
        <Text style={styles.label}>Password length</Text>
        <TextInput style={styles.len} placeholder="0"></TextInput>
      </View>
      <View style={styles.row}>
        <Text style={styles.label}>Include lower case letters</Text>
        <CheckBox></CheckBox>
      </View>

      <View style={styles.row}>
        <Text style={styles.label}>Include upcase letters</Text>
        <CheckBox></CheckBox>
      </View>
      <View style={styles.row}>
        <Text style={styles.label}>Include number</Text>
        <CheckBox></CheckBox>
      </View>

      <View style={styles.row}>
        <Text style={styles.label}>Include special symbol</Text>
        <CheckBox></CheckBox>
      </View>
      <View style={styles.buttonView}>
        <TouchableOpacity style={styles.button}>
          <Text style={{ color: 'white' }}>GENERATE PASSWORD </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#23235B',
    alignItems: 'center',
    // alignContent: 'center',
  },
  header: {
    width: '50%',
  },
  header_text: {
    fontWeight: 'bold',
    color: 'white',
    fontSize: 24,
    marginTop: 20,
  },
  input: {
    width: '100%',
    alignItems: 'center',
    marginTop: 40,
  },
  input_result: {
    width: '80%',
    backgroundColor: '#151537',
    height: 40,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center', // canh theo trục dọc
    marginTop: 20, // thêm khoảng cách giữa các dòng
    width: '80%', // để đồng bộ chiều rộng
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  label: {
    fontWeight: 'bold',
    color: 'white',
    fontSize: 13,
    width: '70%',
  },
  len: {
    color: 'white',
    width: '30%',
  },
  buttonView:{
    width:'80%'
  },
  button:{
    backgroundColor:'#3B3B98',
    padding: '20px',
    alignItems:'center'

  }
});
