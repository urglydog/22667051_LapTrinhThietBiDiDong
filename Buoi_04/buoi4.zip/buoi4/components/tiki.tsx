import React, { useState } from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  TextInput,
  StyleSheet,
} from "react-native";

// import ảnh cục bộ (local image)
import book from '../assets/book.png';

export default function BaiTiki() {
  // quantity: number
  const [quantity, setQuantity] = useState<number>(1);

  const price: number = 141800;
  const total: number = price * quantity;

  return (
    <View style={styles.container}>
      {/* Thông tin sản phẩm */}
      <View style={styles.productRow}>
        <Image source={book} style={styles.image} />
        <View style={styles.productInfo}>
          <Text style={styles.title}>Nguyên hàm tích phân và ứng dụng</Text>
          <Text style={styles.supplier}>Cung cấp bởi Tiki Trading</Text>
          <Text style={styles.price}>{price.toLocaleString()} đ</Text>

          {/* Nút tăng giảm */}
          <View style={styles.quantityRow}>
            <TouchableOpacity
              onPress={() => setQuantity(Math.max(1, quantity - 1))}
              style={styles.btnQty}
            >
              <Text>-</Text>
            </TouchableOpacity>

            <Text style={styles.qty}>{quantity}</Text>

            <TouchableOpacity
              onPress={() => setQuantity(quantity + 1)}
              style={styles.btnQty}
            >
              <Text>+</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {/* Mã giảm giá */}
      <View style={styles.couponRow}>
        <TextInput
          style={styles.couponInput}
          placeholder="Mã giảm giá"
          // TextInput mặc định value là string | undefined
          // Có thể dùng state<string> nếu muốn quản lý mã giảm giá
        />
        <TouchableOpacity style={styles.applyBtn}>
          <Text style={{ color: "white" }}>Áp dụng</Text>
        </TouchableOpacity>
      </View>

      {/* Tạm tính */}
      <View style={styles.rowBetween}>
        <Text>Tạm tính</Text>
        <Text style={styles.price}>{total.toLocaleString()} đ</Text>
      </View>

      {/* Thành tiền */}
      <View style={styles.rowBetween}>
        <Text style={{ fontWeight: "bold" }}>Thành tiền</Text>
        <Text style={[styles.price, { fontWeight: "bold" }]}>
          {total.toLocaleString()} đ
        </Text>
      </View>

      {/* Nút đặt hàng */}
      <TouchableOpacity style={styles.orderBtn}>
        <Text style={{ color: "white", fontWeight: "bold" }}>
          TIẾN HÀNH ĐẶT HÀNG
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#fff" },
  productRow: { flexDirection: "row", marginBottom: 20 },
  image: { width: 100, height: 120, marginRight: 12, resizeMode: "contain" },
  productInfo: { flex: 1 },
  title: { fontSize: 16, fontWeight: "bold" },
  supplier: { color: "gray", marginVertical: 4 },
  price: { color: "red", fontSize: 16 },
  quantityRow: { flexDirection: "row", alignItems: "center", marginTop: 8 },
  btnQty: { borderWidth: 1, borderColor: "#ccc", padding: 6 },
  qty: { marginHorizontal: 10, fontSize: 16 },
  couponRow: { flexDirection: "row", alignItems: "center", marginBottom: 20 },
  couponInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 8,
    marginRight: 10,
  },
  applyBtn: { backgroundColor: "blue", padding: 10, borderRadius: 4 },
  rowBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 10,
  },
  orderBtn: {
    backgroundColor: "red",
    padding: 14,
    borderRadius: 4,
    alignItems: "center",
    marginTop: 20,
  },
});
